import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-go-admin',
  templateUrl: './go-admin.component.html',
  styleUrls: ['./go-admin.component.css']
})
export class GoAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
