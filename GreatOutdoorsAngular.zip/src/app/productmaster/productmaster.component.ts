import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productmaster',
  templateUrl: './productmaster.component.html',
  styleUrls: ['./productmaster.component.css']
})
export class ProductmasterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
