export class Login {
  userName: string;
  password: string;
  phoneNumber: number;
  email: string;
}
